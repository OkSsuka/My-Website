function effects() {
      const nuke = prompt("What is the yield of your nuke? (in kilotons of TNT)");
    var FireballSize = 30*((10*nuke)**(1/3))
    var degree1st = (nuke**0.38)*1.20
  	var degree2nd = nuke**0.4*0.87
    var degree3rd = nuke**0.41*0.67
    var blast1psi = nuke**0.33*2.2
    var blast5psi = nuke**0.33*0.71
    var blast20psi = nuke**0.33*0.28
    alert("Okay, here are your effects: Fireball Size: " + FireballSize + " m. 1st Degree Burns: " + degree1st + " km. 3rd degree burns: " + degree3rd + " km. 1 psi blast range: " + blast1psi + " km. 5 psi blast range: " + blast5psi + " km. 20 psi blast range: " + blast20psi + " km. That\'s it for today!");
}
effects();

<script>
      function sub() {
        var s1 = prompt("What is the number you want to subtract from?")
        var s2 = prompt("What do you want to subtract?")
        alert("Your answer is: " + s1 - s2 + "!");
      }
      </script>

